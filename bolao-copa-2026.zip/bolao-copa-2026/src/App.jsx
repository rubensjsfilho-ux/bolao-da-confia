import { Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Predictions from './pages/Predictions'
import Rankings from './pages/Rankings'
import Champion from './pages/Champion'
import Prizes from './pages/Prizes'
import Admin from './pages/Admin'

function App() {
  const [participant, setParticipant] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const stored = localStorage.getItem('bolao_participant')
    if (stored) {
      try { setParticipant(JSON.parse(stored)) } catch { localStorage.removeItem('bolao_participant') }
    }
    setLoading(false)
  }, [])

  const login  = p => { setParticipant(p); localStorage.setItem('bolao_participant', JSON.stringify(p)) }
  const logout = () => { setParticipant(null); localStorage.removeItem('bolao_participant') }

  if (loading) return (
    <div style={{ minHeight:'100vh', background:'#F4F6F9', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ color:'#009639', fontSize:32, fontWeight:900 }}>⚽</div>
    </div>
  )

  const props = { participant, onLogout: logout }
  return (
    <Routes>
      <Route path="/"          element={!participant ? <Login onLogin={login}/> : <Navigate to="/dashboard" replace/>} />
      <Route path="/dashboard" element={participant ? <Dashboard  {...props}/> : <Navigate to="/" replace/>} />
      <Route path="/palpites"  element={participant ? <Predictions {...props}/> : <Navigate to="/" replace/>} />
      <Route path="/ranking"   element={participant ? <Rankings   {...props}/> : <Navigate to="/" replace/>} />
      <Route path="/campeao"   element={participant ? <Champion   {...props}/> : <Navigate to="/" replace/>} />
      <Route path="/premios"   element={participant ? <Prizes     {...props}/> : <Navigate to="/" replace/>} />
      <Route path="/admin"     element={<Admin />} />
      <Route path="*"          element={<Navigate to="/" replace/>} />
    </Routes>
  )
}

export default App
