# 🐛 Relatório de Correção: Bug do Palpite Não Computado

## Problema Identificado

O participante **Rodolpho** alegava ter feito o palpite para o jogo **França 3x0 Iraque**, mas o palpite não aparecia salvo e os pontos não eram computados após o encerramento da partida.

## Causa Raiz

Havia um **desencontro crítico de IDs de partidas entre o frontend e o banco de dados Supabase**:

### Mapeamento Incorreto (Antes da Correção)

| Jogo | ID no Frontend | ID no Banco | Resultado |
|------|---|---|---|
| **França x Iraque** | 42 | 65 ❌ | Palpite salvo em ID 42, mas jogo estava em ID 65 |
| Senegal x Iraque | 42 ❌ | 42 | Conflito: ID 42 apontava para jogo errado |
| Noruega x França | 61 | 61 | Correto |

### Por que isso causava o bug

1. **Rodolpho vê na tela**: "ID 42 = França x Iraque" (conforme `matches.js`)
2. **Rodolpho faz o palpite**: Sistema salva em `predictions` com `match_id = 42`
3. **No banco de dados**: `match_id = 42` apontava para "Senegal x Iraque" (conforme `supabase-setup.sql`)
4. **Admin encerra o jogo**: Encerra "Senegal x Iraque" com ID 42
5. **Resultado**: 
   - Pontos calculados para o palpite errado (Senegal x Iraque)
   - Palpite de Rodolpho para França x Iraque nunca é encontrado
   - Rodolpho não vê seu palpite e não ganha pontos

## Fluxo de Dados Afetado

```
┌─────────────────────────────────────────────────────────────┐
│ FRONTEND (matches.js)                                       │
│ ID 42 = França x Iraque (2026-06-22 18:00)                 │
└────────────────────┬────────────────────────────────────────┘
                     │ Rodolpho faz palpite
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ PREDICTIONS TABLE (Supabase)                                │
│ match_id: 42, score1: 3, score2: 0                         │
└────────────────────┬────────────────────────────────────────┘
                     │ Admin encerra jogo
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ MATCHES TABLE (Supabase) - ANTES DA CORREÇÃO               │
│ ID 42 = Senegal x Iraque ❌ (ERRADO!)                      │
│ ID 65 = França x Iraque (não é encontrado)                 │
└─────────────────────────────────────────────────────────────┘
```

## Correção Aplicada

Sincronizei **todos os 72 IDs de partidas** no arquivo `supabase-setup.sql` com o calendário correto do frontend (`matches.js`).

### Mapeamento Corrigido (Depois da Correção)

| Jogo | ID | Data | Grupo |
|------|---|---|---|
| **França x Iraque** | **42** ✅ | 2026-06-22 18:00 | I |
| Senegal x Iraque | **62** ✅ | 2026-06-26 16:00 | I |
| Noruega x França | **61** ✅ | 2026-06-26 16:00 | I |

Todos os 72 jogos da fase de grupos agora estão com IDs sincronizados entre frontend e banco.

## Arquivos Modificados

- ✅ **supabase-setup.sql**: Seção "POPULAR TABELA DE JOGOS (FASE DE GRUPOS)" (linhas 74-148)
  - Todos os 72 registros de INSERT foram corrigidos
  - IDs agora correspondem exatamente ao `GROUP_MATCHES` do frontend

## Próximos Passos para Implementação

1. **Backup do banco atual** (importante!)
   ```sql
   -- Fazer backup da tabela predictions antes de resetar matches
   SELECT * INTO predictions_backup FROM predictions;
   ```

2. **Executar o SQL corrigido** no Supabase:
   - Abrir SQL Editor no Supabase
   - Executar o arquivo `supabase-setup.sql` corrigido
   - Usar `ON CONFLICT (id) DO NOTHING` para não sobrescrever dados existentes

3. **Recalcular pontos** (se necessário):
   - No painel Admin, usar a função "Recalcular Todos os Jogos"
   - Isso garantirá que todos os palpites sejam repontuados corretamente

4. **Verificar dados do Rodolpho**:
   - Procurar palpites com `participant_id` do Rodolpho
   - Confirmar que `match_id = 42` agora aponta para "França x Iraque"

## Impacto da Correção

- ✅ Palpites salvos no frontend agora correspondem aos IDs corretos no banco
- ✅ Cálculo de pontos funcionará corretamente ao encerrar partidas
- ✅ Todos os 72 jogos estão sincronizados
- ✅ Sem perda de dados (usando `ON CONFLICT`)

## Teste de Validação

Para confirmar que a correção funcionou:

```sql
-- Verificar se o ID 42 agora é França x Iraque
SELECT id, team1, team2, match_date FROM matches WHERE id = 42;
-- Resultado esperado: (42, 'França', 'Iraque', '2026-06-22 18:00:00+00')

-- Verificar se o ID 62 agora é Senegal x Iraque
SELECT id, team1, team2, match_date FROM matches WHERE id = 62;
-- Resultado esperado: (62, 'Senegal', 'Iraque', '2026-06-26 16:00:00+00')
```

---

**Data da correção**: 23 de junho de 2026  
**Versão corrigida**: bolao-da-confia-main16 (corrigido)
