# 📋 Instruções de Implementação da Correção

## ⚠️ Importante: Leia Antes de Executar

Esta correção resolve o bug onde o palpite do jogo **França 3x0 Iraque** não era computado para o participante Rodolpho.

**Versão**: bolao-da-confia-main16 (corrigido)  
**Data**: 23 de junho de 2026

---

## 🔍 O que foi corrigido?

Sincronizei todos os **72 IDs de partidas** entre o frontend (`src/data/matches.js`) e o banco de dados (`supabase-setup.sql`).

**Mudança crítica**: ID 42 agora é **França x Iraque** (antes era Senegal x Iraque)

---

## 📝 Passo a Passo para Implementar

### Passo 1: Fazer Backup (CRÍTICO!)

Antes de qualquer coisa, faça backup dos dados:

```sql
-- Abrir SQL Editor no Supabase
-- Executar:

-- Backup da tabela predictions
CREATE TABLE predictions_backup_2026_06_23 AS SELECT * FROM predictions;

-- Backup da tabela matches
CREATE TABLE matches_backup_2026_06_23 AS SELECT * FROM matches;

-- Verificar que o backup foi criado
SELECT COUNT(*) FROM predictions_backup_2026_06_23;
SELECT COUNT(*) FROM matches_backup_2026_06_23;
```

### Passo 2: Executar o SQL Corrigido

1. Abra o Supabase Console
2. Vá para **SQL Editor**
3. Abra o arquivo `supabase-setup.sql` (corrigido)
4. **Copie APENAS a seção de INSERT de matches** (linhas 74-148)
5. Cole no SQL Editor
6. Clique em **Run**

O script usará `ON CONFLICT (id) DO NOTHING`, então não sobrescreverá dados existentes.

### Passo 3: Validar a Correção

Execute estas queries para confirmar:

```sql
-- Verificar ID 42 (deve ser França x Iraque)
SELECT id, team1, team2, match_date, group_name 
FROM matches 
WHERE id = 42;

-- Resultado esperado:
-- id: 42
-- team1: França
-- team2: Iraque
-- match_date: 2026-06-22 18:00:00+00
-- group_name: I

-- Verificar ID 62 (deve ser Senegal x Iraque)
SELECT id, team1, team2, match_date, group_name 
FROM matches 
WHERE id = 62;

-- Resultado esperado:
-- id: 62
-- team1: Senegal
-- team2: Iraque
-- match_date: 2026-06-26 16:00:00+00
-- group_name: I

-- Verificar todos os 72 jogos estão presentes
SELECT COUNT(*) FROM matches;
-- Resultado esperado: 72
```

### Passo 4: Recalcular Pontos (Se Necessário)

Se o jogo 42 já foi encerrado com o placar errado, recalcule:

1. Abra o **Painel Admin** do bolão
2. Vá para a aba **Admin**
3. Procure o botão **"Recalcular Todos os Jogos"**
4. Clique para recalcular todos os palpites

Isso garantirá que:
- Palpites salvos em ID 42 sejam repontuados corretamente
- Totais de pontos sejam atualizados para todos os participantes

### Passo 5: Verificar Dados do Rodolpho

Para confirmar que o palpite de Rodolpho agora está correto:

```sql
-- Encontrar o ID do Rodolpho
SELECT id, name FROM participants WHERE name LIKE '%Rodolpho%';

-- Usar o ID retornado para verificar palpites
-- Exemplo: se o ID for 'abc123'
SELECT 
  p.id,
  p.match_id,
  p.score1,
  p.score2,
  p.points,
  m.team1,
  m.team2,
  m.match_date
FROM predictions p
JOIN matches m ON p.match_id = m.id
WHERE p.participant_id = 'abc123'
ORDER BY m.match_date;

-- Procurar por uma linha onde:
-- match_id: 42
-- team1: França
-- team2: Iraque
-- score1: 3
-- score2: 0
```

---

## 🚨 Possíveis Problemas e Soluções

### Problema 1: "Erro: Duplicate key value violates unique constraint"

**Causa**: Tentou inserir um ID que já existe  
**Solução**: Use `ON CONFLICT (id) DO NOTHING` no INSERT (já está no script)

### Problema 2: "Palpites antigos não aparecem mais"

**Causa**: Pode ter deletado dados acidentalmente  
**Solução**: Restaurar do backup:
```sql
DELETE FROM matches;
INSERT INTO matches SELECT * FROM matches_backup_2026_06_23;
```

### Problema 3: "Pontos não foram recalculados"

**Causa**: Precisa executar a função de recalcular  
**Solução**: 
- Use o botão "Recalcular Todos os Jogos" no Admin
- Ou execute manualmente via Admin.jsx

### Problema 4: "Rodolpho ainda não vê seu palpite"

**Causa**: Pode estar em cache no navegador  
**Solução**: 
- Fazer logout e login novamente
- Limpar cache do navegador (Ctrl+Shift+Del)
- Atualizar a página (Ctrl+F5)

---

## ✅ Checklist de Implementação

- [ ] Fiz backup das tabelas `predictions` e `matches`
- [ ] Executei o SQL corrigido no Supabase
- [ ] Validei que ID 42 = França x Iraque
- [ ] Validei que ID 62 = Senegal x Iraque
- [ ] Confirmei que 72 jogos estão no banco
- [ ] Recalculei todos os pontos (se necessário)
- [ ] Verifiquei dados do Rodolpho
- [ ] Testei login/logout e refresh da página
- [ ] Confirmei que o palpite de Rodolpho aparece corretamente

---

## 📞 Suporte

Se encontrar problemas:

1. Verifique os logs do Supabase (Dashboard > Logs)
2. Consulte o arquivo `BUGFIX_REPORT.md` para detalhes técnicos
3. Consulte o arquivo `MUDANCAS_GRUPO_I.md` para ver exatamente o que mudou

---

## 📚 Documentação Adicional

- **BUGFIX_REPORT.md**: Explicação técnica completa do bug e da correção
- **MUDANCAS_GRUPO_I.md**: Detalhes das mudanças específicas no Grupo I
- **supabase-setup.sql**: Script SQL com todas as correções aplicadas

---

**Versão**: 1.0  
**Última atualização**: 23 de junho de 2026
