# Mudanças Específicas - Grupo I (França, Senegal, Noruega, Iraque)

## Comparação de IDs Antes e Depois

### ANTES (Incorreto - supabase-setup.sql original)

```sql
-- GRUPO I
(17, 'França',          'Senegal',          '2026-06-16 19:00:00+00', 'Fase de Grupos', 'I', 'MetLife Stadium',          'Nova York/NJ'),
(18, 'Noruega',         'Iraque',           '2026-06-16 22:00:00+00', 'Fase de Grupos', 'I', 'SoFi Stadium',             'Los Angeles'),
(41, 'França',          'Noruega',          '2026-06-23 22:00:00+00', 'Fase de Grupos', 'I', 'Lincoln Financial Field',  'Filadélfia'),
(42, 'Senegal',         'Iraque',           '2026-06-24 01:00:00+00', 'Fase de Grupos', 'I', 'Estadio Jalisco',          'Guadalajara'),
(65, 'França',          'Iraque',           '2026-06-27 19:00:00+00', 'Fase de Grupos', 'I', 'MetLife Stadium',          'Nova York/NJ'),
(66, 'Senegal',         'Noruega',          '2026-06-27 19:00:00+00', 'Fase de Grupos', 'I', 'Gillette Stadium',         'Boston'),
```

### DEPOIS (Correto - supabase-setup.sql corrigido)

```sql
-- GRUPO I
(18, 'França',          'Senegal',          '2026-06-16 16:00:00+00', 'Fase de Grupos', 'I', 'MetLife Stadium',          'Nova York/NJ'),
(19, 'Iraque',          'Noruega',          '2026-06-16 19:00:00+00', 'Fase de Grupos', 'I', 'Gillette Stadium',         'Boston'),
(41, 'Argentina',       'Áustria',          '2026-06-22 14:00:00+00', 'Fase de Grupos', 'J', 'AT&T Stadium',             'Dallas'),
(42, 'França',          'Iraque',           '2026-06-22 18:00:00+00', 'Fase de Grupos', 'I', 'Lincoln Financial Field',   'Filadélfia'),
(43, 'Noruega',         'Senegal',          '2026-06-22 21:00:00+00', 'Fase de Grupos', 'I', 'MetLife Stadium',          'Nova York/NJ'),
(61, 'Noruega',         'França',           '2026-06-26 16:00:00+00', 'Fase de Grupos', 'I', 'Gillette Stadium',         'Boston'),
(62, 'Senegal',         'Iraque',           '2026-06-26 16:00:00+00', 'Fase de Grupos', 'I', 'BMO Field',                'Toronto'),
```

## Mudanças Críticas

### 🔴 ID 42 - O Problema Principal

| Campo | ANTES | DEPOIS |
|-------|-------|--------|
| **Times** | Senegal x Iraque ❌ | **França x Iraque** ✅ |
| **Data** | 2026-06-24 01:00 | 2026-06-22 18:00 |
| **Estádio** | Estadio Jalisco | Lincoln Financial Field |
| **Cidade** | Guadalajara | Filadélfia |

**Impacto**: Este era o ID que Rodolpho usava para fazer o palpite. Agora está correto!

### 🔴 ID 62 - Senegal x Iraque

| Campo | ANTES | DEPOIS |
|-------|-------|--------|
| **Times** | Não existia | **Senegal x Iraque** ✅ |
| **Data** | - | 2026-06-26 16:00 |
| **Estádio** | - | BMO Field |
| **Cidade** | - | Toronto |

**Impacto**: Agora tem seu próprio ID correto (62), não conflita mais com o ID 42.

### 🔴 ID 43 - Noruega x Senegal

| Campo | ANTES | DEPOIS |
|-------|-------|--------|
| **Times** | Não existia | **Noruega x Senegal** ✅ |
| **Data** | - | 2026-06-22 21:00 |
| **Estádio** | - | MetLife Stadium |
| **Cidade** | - | Nova York/NJ |

**Impacto**: Novo jogo adicionado com ID correto.

### 🔴 ID 61 - Noruega x França

| Campo | ANTES | DEPOIS |
|-------|-------|--------|
| **Times** | Não existia | **Noruega x França** ✅ |
| **Data** | - | 2026-06-26 16:00 |
| **Estádio** | - | Gillette Stadium |
| **Cidade** | - | Boston |

**Impacto**: Novo jogo adicionado com ID correto.

### 🔴 ID 65 e 66 - Mudança de Grupo

| ID | ANTES | DEPOIS |
|----|-------|--------|
| 65 | França x Iraque (Grupo I) | **Egito x Irã (Grupo G)** |
| 66 | Senegal x Noruega (Grupo I) | **Nova Zelândia x Bélgica (Grupo G)** |

**Impacto**: Estes IDs agora pertencem ao Grupo G, não ao Grupo I.

## Resumo das Mudanças no Grupo I

- ✅ ID 18: França x Senegal (mantém, mas com data corrigida)
- ✅ ID 19: Iraque x Noruega (antes era ID 18, agora é 19)
- ✅ ID 42: **França x Iraque** (ANTES era Senegal x Iraque - CORREÇÃO CRÍTICA)
- ✅ ID 43: Noruega x Senegal (novo)
- ✅ ID 61: Noruega x França (novo)
- ✅ ID 62: Senegal x Iraque (novo)

## Sincronização com Frontend

Todos os IDs agora correspondem exatamente ao `GROUP_MATCHES` definido em `src/data/matches.js`:

```javascript
// GRUPO I
{ id:18, team1:'França',         team2:'Senegal',         date:'2026-06-16T16:00:00-03:00', group:'I', ... },
{ id:19, team1:'Iraque',         team2:'Noruega',         date:'2026-06-16T19:00:00-03:00', group:'I', ... },
{ id:41, team1:'Argentina',      team2:'Áustria',         date:'2026-06-22T14:00:00-03:00', group:'J', ... },
{ id:42, team1:'França',         team2:'Iraque',          date:'2026-06-22T18:00:00-03:00', group:'I', ... },
{ id:43, team1:'Noruega',        team2:'Senegal',         date:'2026-06-22T21:00:00-03:00', group:'I', ... },
{ id:61, team1:'Noruega',        team2:'França',          date:'2026-06-26T16:00:00-03:00', group:'I', ... },
{ id:62, team1:'Senegal',        team2:'Iraque',          date:'2026-06-26T16:00:00-03:00', group:'I', ... },
```

✅ **Perfeita correspondência entre frontend e banco de dados!**
